# Codex Start Here

## Current Dallas team details — deployed and verified, 8 October 2026

The approved Dallas Form screen and diamond Home entry are deployed at https://dinkyjunior.github.io/project-dollers/#team/DAL. Application `56fdbe955b274e7f3b4fd36ef9de762e3763bda6` was published by [Pages run 37777138988](https://github.com/dinkyjunior/project-dollers/actions/runs/37777138988), with all three jobs successful. All six specialists accepted the full local and latest source-integration audits, then independently inspected every one of the 36 actual hosted screenshots. Genuine hosted WebKit passed 393×852, 430×896 and 1440×1000, native navigation/refresh/venue controls and natural/reduced/inactive motion; all 231 served runtime bodies returned HTTP 200 and exact hashes, with zero browser/request errors.

Read [the release record](qa/team-details/RELEASE.md), [actual hosted screenshots](qa/team-details/live-captures/index.html), [six hosted reviews](qa/team-details/hosted-review.json) and [source integration](qa/team-details/refresh-integration/release-integration.json). The published manifest is `c336c3cb9907628c96483fd41dd980110789ffab3b96b802d66abb07ad089de1`; the original full audits retain their immutable `fe69378e` source and portable review tag. All 228 code/asset files are unchanged between those source versions. The latest remote data update is preserved, with explicitly verified consumed projections rather than a false claim that raw market CSV bodies are identical.

Ladder → Team details now opens the selected club's form/schedule route; Dallas has working Form, Players & QB and Lineup & Travel tabs, game reports, last-five/source metrics, venue/schedule views, player histories and a sourced upcoming-fixture overview. The second in-depth matchup render has not been supplied and is not claimed implemented. Existing Home/NFL/Steelers research and full-card football motion remain protected; unrelated Page 4 is excluded. Source checks run on entry, focus/resume/reconnect, manual refresh and while active. These are verified published snapshots, not an upstream live play-by-play push feed. Missing/disputed values remain explicit, with their source/retrieval/season context.

Fetch and rebase both remote branches before every ordinary push; never overwrite automatic source changes. Publish through the approved Pages workflow, then verify the exact successful Pages SHA/jobs and actual served bytes. The evidence-only follow-up preserves this tested runtime. Its exact publication receipt and actual source-workflow restoration receipt are saved outside Git to avoid recursive evidence commits; restoration must be checked before reporting completion. Historical reports below remain scoped to their original releases. The approved visual source is the chat attachment; no registered pixel identity or physical iPhone/FPS certification is claimed.

## New authorized Dallas team-details pass — 8 October 2026

The latest user attachment authorizes the generic team-details/Form destination, starting with Dallas, its functional tabs/game reports/schedule/venue controls, and a diamond Home entry button. This supersedes the prior NFL-only inline team-details hold. Preserve the existing Steelers research, football motion and automatic updates; do not add unrelated old Page 4/player-profile features. Work on codex-rebuild, fetch/rebase both remote branches before every ordinary push, and publish only after six independent visual/function/data reviews and actual hosted verification. Read reference/DALLAS_FORM_CHAT_SOURCE.md and the current qa/team-details evidence. Earlier release reports below remain immutable historical acceptance for their original sources.

The team dataset is assets/data/team-details.json, produced by scripts/refresh-team-details.py after the existing snapshot updater. It contains source-linked 2025/2026 regular-season form/schedules for all 32 clubs and enriched Dallas roster/depth/injury statistics. Required-source failures retain the preceding published snapshot; nulls and disputes are explicit. Browser checks on entry/focus/resume/reconnect/manual refresh retain filters, disclosure state and focus; this remains source-driven snapshots, not an upstream live push feed. No final release acceptance is asserted by this setup note.

## Current NFL replica refinement — 8 October 2026 (Sydney)

The user requested a second top-to-bottom Page 2 refinement against the tall NFL chat render. The candidate now has dense condensed native typography, continuous chamfered gold/cyan metal rails, equal illuminated controls, a segmented league medallion, refined local gems, upright Retina helmet artwork and robust native travelling light. Home and Steelers remain locked; no Page 4. Verified records and source timestamps are retained instead of copying illustrative numbers.

Runtime is frozen at 216 files with manifest SHA-256 `674253c96429997b1afafeed5b89e903baa544586867b1069509d1d626ce3286`. Final review/publication facts belong in [the release record](qa/nfl-replica/RELEASE.md), [original browser comparisons](qa/nfl-replica/index.html) and [six-specialist receipt](qa/nfl-replica/release-review.json). Do not apply old acceptance to this candidate. Native top/bottom screenshots establish phone framing; full-content images are qualified capture-only exposures. The approved source is the chat attachment; its original binary was unavailable, so no registered pixel identity is claimed.

Application `5e6c21fca12cd8693c163cfcd66b1f3ad86c2c9b` is deployed and verified by [Pages run 37729699058](https://github.com/dinkyjunior/project-dollers/actions/runs/37729699058). All six specialists accepted the original before/after captures and the genuine hosted phone originals. Complete local Chromium five-size/WebKit two-size, actual hosted WebKit both phones/desktop and actual manual-refresh/frame-text paint checks passed. All 216 served runtime files return HTTP 200/exact hashes with no app browser/network errors. Automatic commit `aacb047` is preserved: 1,806 metadata-only changes, zero facts/types/shapes changed and all 213 other runtime files identical. The effective publication manifest SHA is `f162bd181a850f3a2dd568050016d6d50f8864172d6b86e44858e9cca465068c`. Original reports retain their original source identity. [Actual hosted screenshots](qa/nfl-replica/live-captures/index.html) and [live verification](qa/nfl-replica/hosted-verification.json) are saved. An evidence-only follow-up preserves tested runtime and verifies final public file hashes/refs/Pages head separately. Fetch/rebase both latest remote branches before every ordinary push and preserve automatic source updates. Historical reports below remain immutable evidence for their original source.

## Previous NFL dashboard — superseded visual acceptance

The mandatory final fetch also preserved automatic source update `a6d26f5`, retrieved `2026-10-08T02:19:37Z`. Its 1,806 metadata value changes and two removed obsolete leader-enrichment timestamp keys are explicitly audited; all statistics, 816 leader rows and 200 nondata runtime files remain unchanged. Original full hosted evidence retains its original source identity; separate final-refresh checks verify the newer snapshot.

Application `b08fd0b2a8fbd4c0788ac495ed71be5801485585` is deployed and verified by [Pages run 37715762405](https://github.com/dinkyjunior/project-dollers/actions/runs/37715762405). All six specialists accepted the same source. Actual-hosted WebKit passed both requested phones and desktop, with all 203 runtime files HTTP 200/exact hashes, zero browser/network errors, genuine manual refresh and independent visual acceptance. Open [the live NFL screen](https://dinkyjunior.github.io/project-dollers/#nfl), [hosted screenshots](qa/nfl-diamond/live-captures/index.html) and [the release record](qa/nfl-diamond/RELEASE.md). Evidence-only publication preserves the runtime; its final exact-publication receipt is saved outside Git.

The user's new tall NFL chat render is the Page 2 authority. The NFL dashboard now uses the same compact enclosure as the locked Home screen, with internal scrolling, faceted cyan/gold hardware, local helmet artwork and separate QB/RB/WR tables. Conference, week, division, form and sort controls work. Destination buttons respond inline on NFL; the existing Steelers screen remains available by direct URL. Do not reconnect those destinations or add Page 4 without a new instruction.

Home and Steelers markup and their protected runtime files remain unchanged. The new reference's sample figures are replaced by sourced 2026 records. Read `reference/NFL_DIAMOND_CHAT_SOURCE.md` and `qa/nfl-diamond/RELEASE.md` for the current evidence and publication status. Preserve historical QA; run the shared suite with `npm test -- --output <fresh-directory>` and integration checks with `npm run test:integration -- --output <fresh-report-path>`.

## Current Page 1 luxury refinement — deployed and verified

The further Page 1 pass is deployed at https://dinkyjunior.github.io/project-dollers/. The compact polished chrome/glass entrance, coherent illuminated corridor, native licensed Archivo Black/Inter typography, stronger sport-coloured control edges and natural travelling highlights materially reduce the approved render gap. The original diamond/gold/emerald brand, real sport marks and venue artwork remain. All four sport selectors work; only NFL enters; Coming soon has no Preview only and UFC uses Fighters. Page 4 remains excluded; existing Pages 2–3 and whole-card football research remain protected.

All six independent visual decisions bind the same original 191-file local source and 20 original mobile/desktop captures. Complete Chromium five-size and genuine WebKit two-size suites passed. Fresh authenticated branch rebases preserved `e0419a5`, retrieved 2026-10-07T03:21:30Z. Its 21 genuine roster/source verification differences were independently reviewed rather than called metadata-only; every retained statistic/history remains unchanged and provider disagreement stays visible. Current data/source checks and the complete new-source native two-phone suite passed. All 188 approved nondata runtime files remain byte-identical; original QA remains immutable.

Application `1e99ab368db57e8f929a8eb02f828bbbf3414ac8` was published by [Pages run 37570815916](https://github.com/dinkyjunior/project-dollers/actions/runs/37570815916), all three jobs successful. Full actual-hosted WebKit passed 393×852 and 430×896; independent desktop and the separate 12-image hosted visual acceptance passed. Both public audits received HTTP 200 and exact current hashes for all 191 runtime files, with zero console/JavaScript, HTTP, transport or external runtime errors. Native manual refresh succeeded on both phones with actual HTTP 200 and exact data. Read [the release/evidence](qa/home-luxury/RELEASE.md), [12 actual hosted views](qa/home-luxury/live-captures/index.html) and [eight actual before/after comparisons](qa/home-luxury/before-after/index.html). The approved visual source is the chat attachment; no registered pixel identity or physical iPhone/FPS claim is made.

The temporary GitHub HTTP 401 rejection has resolved; the exact original errors are preserved in [the historical authentication record](qa/home-luxury/publication-blocker.json). No credentials were extracted or duplicated, and its cause is unknown. Continue to fetch/rebase **both latest remote branches** before every ordinary push, explicitly updating `refs/remotes/origin/codex-rebuild` and `refs/remotes/origin/main`; preserve automatic data updates and verify real source changes. The evidence-only follow-up preserves the tested application bytes and its original immutable reports, then checks final public file hashes, both branch refs and exact successful Pages SHA through `qa/home-luxury/verify-publication.py`. Its final receipt is saved outside Git at `/workspace/recovery-qa/home-luxury-final-publication.json` to avoid a recursive evidence commit.

## Previous metal deployment — superseded visual acceptance

The final Page 1 metal entrance and cross-engine floor correction are **deployed and verified** at https://dinkyjunior.github.io/project-dollers/. All six agents accepted all 16 current Chromium/WebKit sport captures against the approved chat render before publication. Complete local Chromium five-size and genuine WebKit two-size suites passed. Actual-hosted WebKit passed both requested phones at 13:13:12 AEDT on 7 October 2026; independent hosted desktop/publication review passed at 13:19:01 AEDT on 7 October 2026. Both hosted audits received HTTP 200 and exact tested hashes for all 184 runtime files with zero console/JavaScript, HTTP, external runtime or transport errors. Independent review accepted all eight final live captures; native manual refresh also passed both phones. Original branding, venues, genuine logos and Pages 2–3 remain; no Page 4. Read [the release record](qa/home-metal/RELEASE.md), [live screenshots](qa/home-metal/live-captures/index.html) and [eight before/after comparisons](qa/home-metal/before-after/index.html).

## Preserved subsequent automatic data refresh

Before final evidence publication, an automatic refresh reached `main` as `fc1c3cb3f6cd0c2190136b9af0da2b7642137c1d`. The ordinary atomic push safely rejected the concurrent update; a fresh fetch/rebase preserved it without overwriting either branch. Retrieval is now 13:20:07 AEDT on 7 October 2026. [Recursive comparison](qa/home-metal/refresh-integration/final-incoming-refresh.json) found 1,776 metadata-only changes and zero factual, scalar-type, dictionary-keyset or list-length changes. All 181 non-data runtime files remain identical to the six-agent-reviewed application `3c4e0894ae94f92e2e20b500ca17d9a56b4e8823`. The three linked snapshot/history/provenance files have new byte hashes; the earlier complete browser reports and presentation captures remain immutable evidence for their original source snapshot.

[Data/checksum validation](qa/home-metal/refresh-integration/final-data-check.json) and [22 data regressions](qa/home-metal/refresh-integration/final-data-tests.txt) passed. [Targeted actual-hosted genuine WebKit verification](qa/home-metal/refresh-integration/post-refresh-results.json) passed both 393×852 and 430×896 at 13:26:20 AEDT. Each size received HTTP 200 and exact current hashes for all 184 runtime files. Selected-week context, complete one-player personal/opponent histories, sources dialog, navigation/back-forward, direct load/reload, images and geometry passed with zero console/JavaScript, HTTP, external or transport errors. [Strict native manual refresh](qa/home-metal/refresh-integration/post-refresh-manual.json) passed both sizes at 13:27:53 AEDT: native click → checking → explicit successful unchanged/updated status, real HTTP 200/304 and exact verified JSON. No site or data responses were substituted and TLS verification stayed enabled. This verifies source revalidation; it does not claim an upstream push feed.

You are working on the `codex-rebuild` branch of `dinkyjunior/project-dollers`.

Read these files before editing code:
1. `AGENTS.md`
2. `README_FOR_CODEX.md`
3. `CODEX_TASK.md`
4. `QA_ACCEPTANCE.md`
5. `REFERENCE_SPEC.md`

If the original approved eight-screen Project Dollar$ render is visible in the Codex conversation context, treat that image as the highest visual authority. If not, use `REFERENCE_SPEC.md` as the fallback until the image is available.

Previous neon release (visually superseded): the user-approved Home-only neon application `32f55a67d500bc8bf646679fb1879e318ef2f4b5` is deployed and verified. Final local Chromium/WebKit QA passed; exact Pages run `37551374311` succeeded at 11:20:40 AEDT, 7 October. Actual-hosted WebKit passed all four states at 393×852 and 430×896 at 11:29:52 AEDT; independent 1440×1000 hosted desktop/publication review passed at 11:26:27 AEDT. Both hosted audits verified all 183 delivered files as HTTP 200 with exact application hashes and zero console/JavaScript, HTTP, external runtime or transport failures. Brand artwork/tagline and inside-gate venue artwork are retained, the repeated below-gate sport-name/DATA & RESEARCH block is removed, and the entrance gate/ring/CTA/selected boxes/walls have stronger illuminated edges and pulse. Preserve readable text, accessible current-sport identity, the four fixed themes, existing controls/Coming-soon scope, reduced motion and lifecycle pauses. Pages 2–3 markup/application remain unchanged; at that application commit data also matched the preceding release. Do not add Page 4. Read `qa/home-neon/RELEASE.md`, the [actual unpaused gallery](qa/home-neon/live-captures/index.html) and [before/after comparisons](qa/home-neon/before-after/index.html). Physical iPhone/Safari controls and device FPS remain untested. Do not generate new branding or venue artwork.

The fresh fetch before final evidence publication preserved incoming automatic data commit `79b3160b56af66121aed80d29c67274b4e04235a`, already deployed by successful Pages run `37552404155`. Its retrieval/check/validator/checksum metadata advances retrieval to 11:31:07 AEDT; [independent recursive comparison](qa/home-neon/post-refresh/source-diff.json) found 1,776 metadata changes and zero factual/type/collection-shape changes. All 180 non-data runtime/assets files remain identical to `32f55a67`. Data/checksum validation and 22 data regressions passed after integration. [Targeted actual-hosted genuine WebKit verification](qa/home-neon/post-refresh/results.json) passed both primary phone sizes at 11:37:02 AEDT (`2026-10-07T00:37:02.046Z`), including 183 integrated hashes/HTTP 200 per size, zero console/HTTP/transport/external errors, navigation/refresh, source dialog, complete personal/opponent history rows for one player, images and geometry. Do not apply old three-data-file hashes to the refreshed snapshot; original full hosted reports remain immutable evidence for the original application/snapshot.

The [narrow hosted manual-refresh companion](qa/home-neon/post-refresh/manual-refresh.json) also passed both phone sizes at 11:39:06 AEDT (`2026-10-07T00:39:06.649Z`): native click → `checking` → successful `unchanged`, reason `manual`, actual HTTP 200/exact refreshed snapshot hash, zero console/JavaScript errors.

The preceding Page 1 launch is complete: the four-sport circular Aperture gate application `ec35fb1b6bcc442cfee89716bc6d1948ba28b557` is deployed and verified on the actual website. The user-reattached gate render supersedes the old eight-screen Home panel only. Final local Chromium/WebKit, actual-hosted mobile WebKit and independent hosted desktop/publication checks passed for that release. Keep its evidence under `qa/home-gate/`, and read `qa/home-gate/RELEASE.md` for exact historical commits/results and the source-image limitation. Those passes do not establish completion of the newer neon refinement.

Approved Home details: singular Project Dollar diamond/gold masthead and emerald money bag; electric-blue NFL, fixed blue-left/red-right NBA, neon-green NRL and neon-red UFC full-panel themes; all sport selectors work; only NFL enters a dashboard. Other entry buttons retain Coming soon but lose "Preview only". UFC's Home navigation uses Fighters; other sports use Teams. Correct NFA to NFL. Add continuously travelling ring lighting, moving background layers, reflections and glints with reduced-motion/hidden-page handling. Before reporting completion, compare all four states at both primary iPhone sizes and desktop, test existing routes/refresh and Pages 2–3 regressions, then deploy and verify the actual hosted URL.

Those behaviours and live motion are verified in `qa/home-gate/hosted-webkit/results.json` (393×852 and 430×896) and `qa/home-gate/independent-hosted/results.json` (1440×1000 desktop). Both actual-hosted audits matched 183 delivered files to tested hashes with strict TLS and no source substitution. The actual unpaused capture gallery is `qa/home-gate/live-captures/index.html`. The original wrapper-selector desktop harness mistake is archived and resolved; physical iPhone/Safari chrome and device FPS remain untested.

For the previous neon pass, use explicit output paths so the prior `qa/home-gate/` evidence is preserved:

```sh
node qa/home-gate.cjs --output qa/home-neon/local-chromium
node qa/home-gate.cjs --engine webkit --mobile-only --output qa/home-neon/local-webkit
node qa/home-gate.cjs --engine webkit --mobile-only --base https://dinkyjunior.github.io/project-dollers/ --output qa/home-neon/hosted-webkit
```

The helper name remains `qa/home-gate.cjs`; its tested default now targets `qa/home-neon/`. Do not explicitly target `qa/home-gate/` outputs, which are immutable historical evidence. Read `qa/home-neon/RELEASE.md` and the existing helper qualifications; genuine WebKit uses the verified workspace runtime and strict TLS. Original chat-reference bytes are unavailable for a repository copy, so do not claim a pixel-registered source composite. Decorative implementation artwork is bundled with provenance in `assets/home/`.

Immediate mission: rebuild/refine Pages 1–3 only. Do not create Page 4.

Work sequentially: Page 1 → visual QA → Page 2 → visual QA → Page 3 → visual QA → integration QA.

Develop on `codex-rebuild` and preserve PR #1's review history. Its original draft is now merged; current production authorization is recorded below. Publish only tested changes and preserve remote automatic updates.

## Development and QA

Use the existing checkout; cloud tasks are already isolated. Do not create a Git worktree unless the user explicitly requests one. Check branch and working changes before editing.

The app is a static site. For local development serve the parent `/workspace` directory so `/project-dollers/` matches GitHub Pages:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory /workspace
```

For reproducible offline browser QA, from `/workspace/project-dollers`:

```sh
npm ci --cache /workspace/.onboarding/npm-cache --no-audit --no-fund
npm test
```

Npm is for QA tooling only; no app build or live API credentials are required. The test starts its own temporary Python server and Chromium and saves six screenshots under `qa/`. Read `qa/README.md` and `ASSET_SOURCES.md`. Never replace verified data with invented values or reintroduce runtime hotlinks. Keep attribution when changing the stadium or font.

The user supplied the approved eight-screen render as a chat attachment. It was used directly for the latest visual comparison and sequential refinements; see `reference/CHAT_SOURCE.md` and `qa/REFERENCE_COMPARISON.md`. The attachment bytes were not available for copying to the expected image path, and the user explicitly instructed continuing without blocking. Do not mistake that file limitation for absence of an approved source. Current screenshots and side-by-side before/after evidence remain subject to user visual approval.

## Latest production pass

The latest user request authorizes publishing after final QA; it supersedes the earlier no-main restriction for this completed pass. Preserve the Pages 1–3 scope. Current runtime data is `assets/data/current.json`, generated by `scripts/refresh-data.py`, not the historical `snapshot.js`. Run `python3 qa/data.test.py`, `npm run data:check`, `npm test` and post-publication `npm run qa:hosted`. Read current `CODEX_HANDOFF_STATUS.md` and `DEPLOYMENT.md` for exact external verification limits.

## October 2 follow-up

The user requested full personal last-five and weekly-opponent game statistics, automatic updates, stronger illuminated borders and a sharper/more interactive Home. The lazy history bundle is checksum-linked to the snapshot; do not replace it with guessed figures or treat a missing statistics row as an appearance. Preserve selected-week matchup context and state through refresh. Run `npm run test:data`, `npm run test:sources`, `npm run test:updates`, `npm run test:integration`, `npm test`, and `npm run data:check`. Read the latest `qa/next-pass/` reviews. Actual upstream push remains unconnected and must not be described as live.

The final application release is `a301293`, published on both branches; PR #1 was already merged. Its description records this follow-up separately from the original PR head. Actual hosted WebKit and Firefox QA passed both primary sizes with strict TLS; use `npm run qa:hosted:webkit` and `npm run qa:hosted:firefox` with the documented workspace runtimes in this cloud. Default Chromium's hosted TLS failure is engine-specific and does not supersede those passes. Read `qa/hosted/README.md` and `qa/next-pass/PUBLICATION_STATUS.md`. Fetch/rebase the latest `codex-rebuild` and integrate incoming production data before every subsequent push.

The recovered targeted refresh report at `qa/hosted/refresh-smoke.json` confirms that `9633c03` also passed both 393×852 and 430×896 hosted WebKit checks at 12:27:13 AEST on 2 October. Do not leave its 430px result described as pending.
